from resources.mysql_data_service import MySQLDataService, MySQLDataServiceConfig


def get_svc() -> MySQLDataService:
    config = MySQLDataServiceConfig()
    svc = MySQLDataService(config)
    return svc


def t1():
    get_svc()


def t_where_clause():
    predicate = {"nameLast": "Williams", "nameFirst": "Ted", "H": 72}
    svc = get_svc()
    res, args = svc.predicate_to_where_clause_args(predicate)
    print("t_where_clause: clause=", res, "args=", args)


def t_build_sql():
    predicate = {"nameLast": "Williams", "nameFirst": "Ted"}
    svc = get_svc()
    res = svc.retrieve("lahmansbaseballdb", "people",
                                 predicate,
                                 ["nameLast", "nameFirst", "birthCity"])
    print("t_build_sql: clause=", res)


def t_build_select():
    predicate = {"nameLast": "Williams", "nameFirst": "Ted", "H": 72}
    cols = ["nameLast", "nameFirst", "birthYear"]
    svc = get_svc()
    sql, args = svc.build_select("lahmansbaseballdb", "People", predicate, project=cols)
    print("t_select=", sql, args)


def t_select():
    svc = get_svc()
    database = "s23_w4111_hw2_jz3504"
    collection = "name_basics_all"
    predicate = {"birthYear":1975}
    result = svc.retrieve(database, collection, predicate, project=["primaryName", "primaryProfession"])


def t_build_delete():
    predicate = {"primaryName": "Tom Hanks", "birthYear": "1968"}
    svc = get_svc()
    res = svc.build_delete("s23_w4111_hm2_jz3504", "name_basics_all",
                                 predicate)

    print("t_build_delete: clause=", res)


def t_cool():
    predicate = {"nameLast": "Williams", "nameFirst": "Ted"}
    cols = None
    svc = get_svc()
    sql, args = svc.build_select("lahmansbaseballdb", "people",
                       predicate, project=cols)
    print("t_select =:", sql, args)
    result = svc.run_q(sql, args, fetch=True)
    print("Cool is \n", json.dumps(result, indent=2, default=str))


def t_delete():
    predicate = {"primaryName": "cat", "birthYear": "2002"}
    svc = get_svc()
    res = svc.build_delete("s23_w4111_hm2_jz3504", "name_basics_all",
                                 predicate)
    print("t_delete: clause=", res)
    res = svc.run_q(res, args, fetch=False)
    print("Testing delete return", res)


def t_delete_all():
    predicate = {"primaryName": "cat", "birthYear": "2002"}
    svc = get_svc()
    res = svc.build_delete("s23_w4111_hm2_jz3504", "name_basics_all",
                                 predicate)
    print("Testing delete return", res)


def t_build_update():
    predicate = {"nameLast": "Williams", "nameFirst": "Ted"}
    svc = get_svc()
    res = svc.update("lahmansbaseballdb", "people", predicate,["asdhjk","dfgh","sdfgh"])
    print("t_build_update: clause=", res)


def t_build_insert():
    predicate = {"nameLast": "Williams", "nameFirst": "Ted"}
    svc = get_svc()
    res = svc.insert("lahmansbaseballdb", "people")
    print("t_build_update: clause=", res)


if __name__ == "__main__":

    # t_build_sql()
    # t_build_delete()
    # t_build_update()
    # t_where_clause()
    # t_build_select()
    # t_select() = select nameLast, nameFirst, birthYear from lahmansbaseballdb.People where nameLast=%s and H=%s['Williams','Ted',72]
    # t_cool()
    # t_delete()
    # t_delete_all() full_sql = delete from s22_w4111_hm2_jz3504.name_basics_all where primaryName='cat, birthYear=2002